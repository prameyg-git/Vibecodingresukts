import EventCard from './EventCard';
import { EmptyState, ErrorState, Spinner } from './States';
import type { EventItem } from '../types';

interface Props {
  events: EventItem[];
  loading?: boolean;
  error?: string;
  onRetry?: () => void;
  emptyTitle?: string;
  emptyHint?: string;
}

export default function EventGrid({ events, loading, error, onRetry, emptyTitle = 'No events found', emptyHint }: Props) {
  if (loading) return <Spinner />;
  if (error) return <ErrorState message={error} onRetry={onRetry} />;
  if (!events.length) return <EmptyState title={emptyTitle} hint={emptyHint} />;
  return (
    <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
      {events.map((e) => <EventCard key={e.id} event={e} />)}
    </div>
  );
}
