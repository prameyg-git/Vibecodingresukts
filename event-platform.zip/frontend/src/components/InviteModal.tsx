import { useEffect, useState } from 'react';
import { api } from '../services/api';
import { useToast } from '../context/ToastContext';
import { Spinner } from './States';
import type { EventItem } from '../types';

export default function InviteModal({ event, onClose }: { event: EventItem; onClose: () => void }) {
  const toast = useToast();
  const [link, setLink] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    api.createInvite(event.id).then(setLink).catch((e) => setError(e.message));
  }, [event.id]);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(link);
      toast.success('Link copied');
    } catch {
      toast.error('Could not copy — select the link and copy manually');
    }
  };

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/40 p-4" onClick={onClose}>
      <div className="card w-full max-w-md p-5" onClick={(e) => e.stopPropagation()}>
        <h3 className="text-lg font-semibold">Invite friends</h3>
        <p className="mb-4 truncate text-sm text-slate-500">{event.title}</p>
        {error ? (
          <p className="text-sm text-red-600">{error}</p>
        ) : !link ? (
          <Spinner label="Creating link…" />
        ) : (
          <div className="flex gap-2">
            <input className="input" readOnly value={link} onFocus={(e) => e.target.select()} />
            <button className="btn-primary" onClick={copy}>Copy</button>
          </div>
        )}
        <div className="mt-4 text-right">
          <button className="btn-outline" onClick={onClose}>Close</button>
        </div>
      </div>
    </div>
  );
}
