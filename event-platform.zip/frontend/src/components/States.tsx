import type { ReactNode } from 'react';

export const Spinner = ({ label = 'Loading…' }: { label?: string }) => (
  <div className="flex items-center justify-center gap-3 py-16 text-slate-500">
    <div className="h-5 w-5 animate-spin rounded-full border-2 border-indigo-600 border-t-transparent" />
    <span className="text-sm">{label}</span>
  </div>
);

export const ErrorState = ({ message, onRetry }: { message: string; onRetry?: () => void }) => (
  <div className="rounded-xl border border-red-200 bg-red-50 p-6 text-center">
    <p className="text-sm text-red-700">{message}</p>
    {onRetry && <button className="btn-outline mt-3" onClick={onRetry}>Try again</button>}
  </div>
);

export const EmptyState = ({ title, hint, children }: { title: string; hint?: string; children?: ReactNode }) => (
  <div className="rounded-xl border border-dashed border-slate-300 p-10 text-center">
    <p className="font-medium text-slate-700">{title}</p>
    {hint && <p className="mt-1 text-sm text-slate-500">{hint}</p>}
    {children && <div className="mt-4">{children}</div>}
  </div>
);
