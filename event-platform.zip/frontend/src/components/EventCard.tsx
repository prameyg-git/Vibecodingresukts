import { useEffect, useState } from 'react';
import { useEvents } from '../context/EventsContext';
import { fmtDate, fmtTime } from '../utils';
import InviteModal from './InviteModal';
import type { EventItem } from '../types';

export default function EventCard({ event }: { event: EventItem }) {
  const { rsvpIds, rsvp, cancel, friends, ensureFriends } = useEvents();
  const [busy, setBusy] = useState(false);
  const [inviting, setInviting] = useState(false);
  const going = rsvpIds.has(event.id);

  useEffect(() => { ensureFriends(event.id); }, [event.id, ensureFriends]);

  const toggle = async () => {
    setBusy(true);
    await (going ? cancel(event.id) : rsvp(event));
    setBusy(false);
  };

  return (
    <div className="card flex flex-col overflow-hidden">
      {event.image ? (
        <img src={event.image} alt={event.title} loading="lazy" className="h-40 w-full object-cover" />
      ) : (
        <div className="h-40 w-full bg-gradient-to-br from-indigo-400 to-purple-500" />
      )}
      <div className="flex flex-1 flex-col gap-1 p-4">
        <div className="flex items-start justify-between gap-2">
          <h3 className="font-semibold leading-snug">{event.title}</h3>
          {going && <span className="shrink-0 rounded-full bg-emerald-100 px-2 py-0.5 text-xs font-medium text-emerald-700">Going</span>}
        </div>
        <p className="text-sm text-slate-600">📅 {fmtDate(event.date)} · {fmtTime(event)}</p>
        {event.venue && <p className="text-sm text-slate-600">📍 {event.venue}</p>}
        {event.location && <p className="text-sm text-slate-500">🏙️ {event.location}</p>}
        <p className="mt-1 text-sm font-medium text-indigo-700">
          Friends Attending: {friends[event.id] ?? '…'}
        </p>
        <div className="mt-auto flex flex-wrap gap-2 pt-3">
          {going ? (
            <>
              <button className="btn-primary flex-1" onClick={() => setInviting(true)}>Invite</button>
              <button className="btn-danger" disabled={busy} onClick={toggle}>Cancel RSVP</button>
            </>
          ) : (
            <button className="btn-primary w-full" disabled={busy} onClick={toggle}>
              {busy ? 'Saving…' : 'RSVP / Interested'}
            </button>
          )}
        </div>
      </div>
      {inviting && <InviteModal event={event} onClose={() => setInviting(false)} />}
    </div>
  );
}
