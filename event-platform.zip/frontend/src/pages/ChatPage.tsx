import { useEffect, useRef, useState, type FormEvent } from 'react';
import EventCard from '../components/EventCard';
import { api } from '../services/api';
import type { ChatMessage } from '../types';

const SUGGESTIONS = [
  'Show events this weekend',
  'Show events tomorrow',
  'Find music events',
  'Find events in Mumbai',
  'What am I attending?',
  'Show my RSVPs',
];

export default function ChatPage() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'bot', text: 'Hi! Ask me about events — try one of the suggestions below.', events: [] },
  ]);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages, sending]);

  const send = async (text: string) => {
    const msg = text.trim();
    if (!msg || sending) return;
    setMessages((m) => [...m, { role: 'user', text: msg, events: [] }]);
    setInput('');
    setSending(true);
    try {
      const r = await api.chat(msg);
      setMessages((m) => [...m, { role: 'bot', text: r.text || (r.events.length ? '' : "I couldn't find anything."), events: r.events }]);
    } catch (e) {
      setMessages((m) => [...m, { role: 'bot', text: `⚠️ ${(e as Error).message}`, events: [] }]);
    } finally {
      setSending(false);
    }
  };

  const submit = (e: FormEvent) => { e.preventDefault(); send(input); };

  return (
    <div className="flex h-[calc(100vh-9rem)] flex-col">
      <h1 className="mb-3 text-2xl font-bold">Chat</h1>
      <div className="card flex-1 space-y-4 overflow-y-auto p-4">
        {messages.map((m, i) => (
          <div key={i} className={m.role === 'user' ? 'flex justify-end' : ''}>
            <div className={m.role === 'user' ? 'max-w-[85%]' : 'w-full'}>
              {m.text && (
                <div className={`inline-block rounded-2xl px-4 py-2 text-sm ${m.role === 'user' ? 'bg-indigo-600 text-white' : 'bg-slate-100'}`}>
                  {m.text}
                </div>
              )}
              {m.events.length > 0 && (
                <div className="mt-3 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {m.events.map((ev) => <EventCard key={ev.id} event={ev} />)}
                </div>
              )}
            </div>
          </div>
        ))}
        {sending && <div className="inline-block rounded-2xl bg-slate-100 px-4 py-2 text-sm text-slate-500">Typing…</div>}
        <div ref={endRef} />
      </div>
      <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
        {SUGGESTIONS.map((s) => (
          <button key={s} onClick={() => send(s)} disabled={sending} className="btn-outline whitespace-nowrap rounded-full text-xs">{s}</button>
        ))}
      </div>
      <form onSubmit={submit} className="mt-2 flex gap-2">
        <input className="input" placeholder="Ask about events…" value={input} onChange={(e) => setInput(e.target.value)} />
        <button className="btn-primary" disabled={sending || !input.trim()}>Send</button>
      </form>
    </div>
  );
}
