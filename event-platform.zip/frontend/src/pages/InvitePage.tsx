import { useEffect, useRef, useState } from 'react';
import { Link, useLocation, useNavigate, useParams } from 'react-router-dom';
import { ErrorState, Spinner } from '../components/States';
import { useAuth } from '../context/AuthContext';
import { useEvents } from '../context/EventsContext';
import { useToast } from '../context/ToastContext';
import { api } from '../services/api';
import { fmtDate, fmtTime } from '../utils';
import type { InviteInfo } from '../types';

export default function InvitePage() {
  const { token = '' } = useParams();
  const { user } = useAuth();
  const { loadRsvps } = useEvents();
  const toast = useToast();
  const navigate = useNavigate();
  const location = useLocation();
  const [invite, setInvite] = useState<InviteInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const load = () => {
    setLoading(true);
    setError('');
    api.getInvite(token).then(setInvite).catch((e) => setError(e.message)).finally(() => setLoading(false));
  };
  const loadedToken = useRef('');
  useEffect(() => {
    if (loadedToken.current === token) return; // StrictMode runs effects twice in dev; count one click per open
    loadedToken.current = token;
    load();
  }, [token]);

  const accept = async () => {
    if (!user) {
      navigate('/login', { state: { from: location } });
      return;
    }
    setBusy(true);
    try {
      await api.acceptInvite(token);
      toast.success("You're going!");
      await loadRsvps();
      navigate('/dashboard');
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const ev = invite?.event;

  return (
    <div className="flex min-h-screen items-center justify-center p-4">
      <div className="w-full max-w-md">
        {loading ? <Spinner label="Loading invite…" /> : error ? (
          <ErrorState message={error} onRetry={load} />
        ) : ev && (
          <div className="card overflow-hidden">
            {ev.image ? <img src={ev.image} alt={ev.title} className="h-48 w-full object-cover" /> : <div className="h-48 bg-gradient-to-br from-indigo-400 to-purple-500" />}
            <div className="space-y-2 p-5">
              <p className="text-sm font-medium text-indigo-600">
                {invite?.inviter ? `${invite.inviter} invited you` : "You're invited"}
              </p>
              <h1 className="text-xl font-bold">{ev.title}</h1>
              <p className="text-sm text-slate-600">📅 {fmtDate(ev.date)} · {fmtTime(ev)}</p>
              {ev.venue && <p className="text-sm text-slate-600">📍 {ev.venue}</p>}
              {ev.location && <p className="text-sm text-slate-500">🏙️ {ev.location}</p>}
              <button className="btn-primary mt-3 w-full" disabled={busy} onClick={accept}>
                {busy ? 'Saving…' : user ? 'RSVP to this event' : 'Login to RSVP'}
              </button>
              {user && <Link to="/events" className="block pt-1 text-center text-sm text-slate-500 hover:underline">Browse more events</Link>}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
