import { useEffect, useState, type FormEvent } from 'react';
import { ErrorState, Spinner } from '../components/States';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { api } from '../services/api';

export default function ProfilePage() {
  const { setUser } = useAuth();
  const toast = useToast();
  const [form, setForm] = useState({ name: '', location: '', enabled: true, hoursBefore: 24 });
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const load = () => {
    setLoading(true);
    setError('');
    api.getProfile()
      .then((u) => {
        setEmail(u.email);
        setForm({
          name: u.name,
          location: u.location ?? '',
          enabled: u.reminderSettings?.enabled ?? true,
          hoursBefore: u.reminderSettings?.hoursBefore ?? 24,
        });
      })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  };
  useEffect(load, []);

  const save = async (e: FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const u = await api.updateProfile({
        name: form.name,
        location: form.location,
        reminderSettings: { enabled: form.enabled, hoursBefore: Number(form.hoursBefore) },
      });
      setUser(u);
      toast.success('Profile updated');
    } catch (err) {
      toast.error((err as Error).message);
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <Spinner />;
  if (error) return <ErrorState message={error} onRetry={load} />;

  return (
    <form onSubmit={save} className="card mx-auto max-w-lg space-y-4 p-6">
      <h1 className="text-2xl font-bold">Profile</h1>
      <label className="block text-sm font-medium">Email
        <input className="input mt-1 bg-slate-100" value={email} disabled />
      </label>
      <label className="block text-sm font-medium">Name
        <input className="input mt-1" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
      </label>
      <label className="block text-sm font-medium">Location
        <input className="input mt-1" placeholder="e.g. Mumbai" value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} />
      </label>
      <fieldset className="space-y-3 rounded-lg border border-slate-200 p-4">
        <legend className="px-1 text-sm font-medium">Reminders</legend>
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" checked={form.enabled} onChange={(e) => setForm({ ...form, enabled: e.target.checked })} />
          Remind me before events I RSVP to
        </label>
        <label className="block text-sm">Hours before event
          <input className="input mt-1" type="number" min={1} max={168} disabled={!form.enabled}
            value={form.hoursBefore} onChange={(e) => setForm({ ...form, hoursBefore: Number(e.target.value) })} />
        </label>
      </fieldset>
      <button className="btn-primary w-full" disabled={saving}>{saving ? 'Saving…' : 'Save changes'}</button>
    </form>
  );
}
