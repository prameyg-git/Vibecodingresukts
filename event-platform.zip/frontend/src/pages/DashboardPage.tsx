import { Link } from 'react-router-dom';
import EventGrid from '../components/EventGrid';
import { useEvents } from '../context/EventsContext';

export default function DashboardPage() {
  const { rsvpEvents, rsvpLoading, rsvpError, loadRsvps } = useEvents();
  return (
    <div className="space-y-5">
      <h1 className="text-2xl font-bold">My RSVPs</h1>
      <EventGrid
        events={rsvpEvents}
        loading={rsvpLoading && !rsvpEvents.length}
        error={rsvpError}
        onRetry={loadRsvps}
        emptyTitle="You haven't RSVP'd to any events yet"
        emptyHint="Browse events and tap RSVP to see them here."
      />
      {!rsvpEvents.length && !rsvpLoading && !rsvpError && (
        <div className="text-center"><Link to="/events" className="btn-primary">Browse events</Link></div>
      )}
    </div>
  );
}
