import { useEffect, useMemo, useState } from 'react';
import EventGrid from '../components/EventGrid';
import { ErrorState, Spinner } from '../components/States';
import { api } from '../services/api';
import { dateKey, fmtDate } from '../utils';
import type { EventItem } from '../types';

const pad = (n: number) => String(n).padStart(2, '0');
const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export default function CalendarPage() {
  const today = new Date();
  const [cursor, setCursor] = useState(new Date(today.getFullYear(), today.getMonth(), 1));
  const [selected, setSelected] = useState('');
  const [events, setEvents] = useState<EventItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const load = () => {
    setLoading(true);
    setError('');
    const first = new Date(cursor.getFullYear(), cursor.getMonth(), 1);
    const last = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0);
    const key = (d: Date) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
    api
      .getEvents({ startDate: key(first), endDate: key(last), size: '200' })
      .then(setEvents)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  };
  useEffect(load, [cursor]);

  const byDate = useMemo(() => {
    const m = new Map<string, EventItem[]>();
    events.forEach((e) => {
      const k = dateKey(e.date);
      if (k) m.set(k, [...(m.get(k) ?? []), e]);
    });
    return m;
  }, [events]);

  const y = cursor.getFullYear();
  const mo = cursor.getMonth();
  const daysInMonth = new Date(y, mo + 1, 0).getDate();
  const blanks = new Date(y, mo, 1).getDay();
  const todayKey = `${today.getFullYear()}-${pad(today.getMonth() + 1)}-${pad(today.getDate())}`;
  const shift = (n: number) => setCursor(new Date(y, mo + n, 1));

  if (loading) return <Spinner />;
  if (error) return <ErrorState message={error} onRetry={load} />;

  return (
    <div className="space-y-6">
      <div className="card p-4">
        <div className="mb-4 flex items-center justify-between">
          <button className="btn-outline" onClick={() => shift(-1)}>← Prev</button>
          <h2 className="text-lg font-semibold">{cursor.toLocaleDateString(undefined, { month: 'long', year: 'numeric' })}</h2>
          <button className="btn-outline" onClick={() => shift(1)}>Next →</button>
        </div>
        <div className="grid grid-cols-7 gap-1 text-center text-xs font-medium text-slate-500">
          {DAYS.map((d) => <div key={d} className="py-1">{d}</div>)}
        </div>
        <div className="grid grid-cols-7 gap-1">
          {Array.from({ length: blanks }).map((_, i) => <div key={`b${i}`} />)}
          {Array.from({ length: daysInMonth }, (_, i) => i + 1).map((d) => {
            const key = `${y}-${pad(mo + 1)}-${pad(d)}`;
            const count = byDate.get(key)?.length ?? 0;
            const isSel = key === selected;
            return (
              <button
                key={key}
                onClick={() => setSelected(key)}
                className={`relative flex h-14 flex-col items-center justify-center rounded-lg border text-sm transition sm:h-16
                  ${isSel ? 'border-indigo-600 bg-indigo-600 text-white' : count ? 'border-indigo-200 bg-indigo-50 font-semibold text-indigo-700 hover:bg-indigo-100' : 'border-transparent hover:bg-slate-100'}
                  ${key === todayKey && !isSel ? 'ring-1 ring-slate-400' : ''}`}
              >
                {d}
                {count > 0 && <span className={`text-[10px] ${isSel ? 'text-indigo-100' : 'text-indigo-500'}`}>{count} event{count > 1 ? 's' : ''}</span>}
              </button>
            );
          })}
        </div>
      </div>

      {selected ? (
        <div className="space-y-3">
          <h3 className="text-lg font-semibold">Events on {fmtDate(selected)}</h3>
          <EventGrid events={byDate.get(selected) ?? []} emptyTitle="No events on this date" />
        </div>
      ) : (
        <p className="text-center text-sm text-slate-500">Select a highlighted date to see its events.</p>
      )}
    </div>
  );
}
