import { useState, type FormEvent } from 'react';
import { Link, Navigate, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function AuthPage({ mode }: { mode: 'login' | 'register' }) {
  const { user, login, register } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const from = (location.state as { from?: { pathname: string; search?: string } } | null)?.from;
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const isLogin = mode === 'login';

  if (user) return <Navigate to={from ? from.pathname + (from.search ?? '') : '/events'} replace />;

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      if (isLogin) await login(form.email, form.password);
      else await register(form.name, form.email, form.password);
      navigate(from ? from.pathname + (from.search ?? '') : '/events', { replace: true });
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) => setForm({ ...form, [k]: e.target.value });

  return (
    <div className="flex min-h-screen items-center justify-center p-4">
      <form onSubmit={submit} className="card w-full max-w-sm space-y-4 p-6">
        <h1 className="text-center text-2xl font-bold text-indigo-600">🎟️ Eventify</h1>
        <p className="text-center text-sm text-slate-500">{isLogin ? 'Sign in to your account' : 'Create your account'}</p>
        {!isLogin && <input className="input" placeholder="Name" required value={form.name} onChange={set('name')} />}
        <input className="input" type="email" placeholder="Email" required value={form.email} onChange={set('email')} />
        <input className="input" type="password" placeholder="Password" required minLength={6} value={form.password} onChange={set('password')} />
        {error && <p className="rounded-lg bg-red-50 p-2 text-sm text-red-600">{error}</p>}
        <button className="btn-primary w-full" disabled={busy}>{busy ? 'Please wait…' : isLogin ? 'Login' : 'Register'}</button>
        <p className="text-center text-sm text-slate-500">
          {isLogin ? (
            <>No account? <Link className="text-indigo-600 hover:underline" to="/register" state={location.state}>Register</Link></>
          ) : (
            <>Have an account? <Link className="text-indigo-600 hover:underline" to="/login" state={location.state}>Login</Link></>
          )}
        </p>
      </form>
    </div>
  );
}
