import { useCallback, useEffect, useState, type FormEvent } from 'react';
import EventGrid from '../components/EventGrid';
import { api } from '../services/api';
import type { EventItem } from '../types';

export default function EventsPage() {
  const [filters, setFilters] = useState({ keyword: '', city: '', date: '' });
  const [applied, setApplied] = useState(filters);
  const [events, setEvents] = useState<EventItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const load = useCallback(() => {
    setLoading(true);
    setError('');
    api.getEvents(applied).then(setEvents).catch((e) => setError(e.message)).finally(() => setLoading(false));
  }, [applied]);

  useEffect(load, [load]);

  const submit = (e: FormEvent) => { e.preventDefault(); setApplied(filters); };
  const clear = () => { const f = { keyword: '', city: '', date: '' }; setFilters(f); setApplied(f); };
  const set = (k: keyof typeof filters) => (e: React.ChangeEvent<HTMLInputElement>) => setFilters({ ...filters, [k]: e.target.value });

  return (
    <div className="space-y-5">
      <h1 className="text-2xl font-bold">Discover events</h1>
      <form onSubmit={submit} className="grid gap-2 sm:grid-cols-[1fr_1fr_auto_auto_auto]">
        <input className="input" placeholder="Keyword (e.g. music)" value={filters.keyword} onChange={set('keyword')} />
        <input className="input" placeholder="City (e.g. Mumbai)" value={filters.city} onChange={set('city')} />
        <input className="input" type="date" value={filters.date} onChange={set('date')} />
        <button className="btn-primary">Search</button>
        <button type="button" className="btn-outline" onClick={clear}>Clear</button>
      </form>
      <EventGrid events={events} loading={loading} error={error} onRetry={load} emptyHint="Try a different keyword, city or date." />
    </div>
  );
}
