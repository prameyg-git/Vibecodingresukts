import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from 'react';
import { api, toCount, tokenStore } from '../services/api';
import { connectSocket, disconnectSocket } from '../services/socket';
import { useAuth } from './AuthContext';
import { useToast } from './ToastContext';
import type { EventItem } from '../types';

interface EventsValue {
  rsvpIds: Set<string>;
  rsvpEvents: EventItem[];
  rsvpLoading: boolean;
  rsvpError: string;
  friends: Record<string, number>;
  loadRsvps: () => Promise<void>;
  rsvp: (event: EventItem) => Promise<boolean>;
  cancel: (eventId: string) => Promise<boolean>;
  ensureFriends: (eventId: string) => void;
}

const Ctx = createContext<EventsValue>(null!);
export const useEvents = () => useContext(Ctx);

export function EventsProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const toast = useToast();
  const [rsvpEvents, setRsvpEvents] = useState<EventItem[]>([]);
  const [rsvpIds, setRsvpIds] = useState<Set<string>>(new Set());
  const [rsvpLoading, setRsvpLoading] = useState(false);
  const [rsvpError, setRsvpError] = useState('');
  const [friends, setFriends] = useState<Record<string, number>>({});
  const requested = useRef(new Set<string>());

  const setCount = (id: string, c: number) => setFriends((f) => ({ ...f, [id]: c }));

  const loadRsvps = useCallback(async () => {
    setRsvpLoading(true);
    setRsvpError('');
    try {
      const { ids, events } = await api.getRsvps();
      setRsvpIds(new Set(ids));
      setRsvpEvents(events);
    } catch (e) {
      setRsvpError((e as Error).message);
    } finally {
      setRsvpLoading(false);
    }
  }, []);

  const ensureFriends = useCallback((id: string) => {
    if (!id || requested.current.has(id)) return;
    requested.current.add(id);
    api.getFriendsAttending(id).then((c) => setCount(id, c)).catch(() => requested.current.delete(id));
  }, []);

  // Load RSVPs + real-time updates while logged in
  useEffect(() => {
    if (!user) {
      setRsvpIds(new Set());
      setRsvpEvents([]);
      setFriends({});
      requested.current.clear();
      return;
    }
    loadRsvps();
    const socket = connectSocket(tokenStore.get());
    const handler = (p: any) => {
      const id = String(p?.eventId ?? p?.event_id ?? p?.event?.id ?? '');
      if (!id) return;
      const c = toCount(p);
      if (c !== undefined) setCount(id, c);
      else api.getFriendsAttending(id).then((n) => setCount(id, n)).catch(() => {});
    };
    socket.on('friends-attending-updated', handler);
    return () => {
      socket.off('friends-attending-updated', handler);
      disconnectSocket();
    };
  }, [user?.id, loadRsvps]);

  const rsvp = async (event: EventItem) => {
    try {
      await api.rsvp(event.id);
      setRsvpIds((s) => new Set(s).add(event.id));
      setRsvpEvents((l) => (l.some((e) => e.id === event.id) ? l : [event, ...l]));
      toast.success("You're going! Invite your friends.");
      return true;
    } catch (e) {
      toast.error((e as Error).message);
      return false;
    }
  };

  const cancel = async (id: string) => {
    try {
      await api.cancelRsvp(id);
      setRsvpIds((s) => { const n = new Set(s); n.delete(id); return n; });
      setRsvpEvents((l) => l.filter((e) => e.id !== id));
      toast.success('RSVP cancelled');
      return true;
    } catch (e) {
      toast.error((e as Error).message);
      return false;
    }
  };

  return (
    <Ctx.Provider value={{ rsvpIds, rsvpEvents, rsvpLoading, rsvpError, friends, loadRsvps, rsvp, cancel, ensureFriends }}>
      {children}
    </Ctx.Provider>
  );
}
