import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react';
import { api, onUnauthorized, tokenStore } from '../services/api';
import type { User } from '../types';

interface AuthValue {
  user: User | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string) => Promise<void>;
  logout: () => void;
  setUser: (u: User) => void;
}

const AuthCtx = createContext<AuthValue>(null!);
export const useAuth = () => useContext(AuthCtx);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(!!tokenStore.get());

  const logout = useCallback(() => {
    tokenStore.clear();
    setUser(null);
  }, []);

  useEffect(() => {
    onUnauthorized(logout);
    if (!tokenStore.get()) return;
    api.me().then(setUser).catch(logout).finally(() => setLoading(false));
  }, [logout]);

  const finish = async (token?: string, u?: User) => {
    if (!token) throw new Error('No token returned by server');
    tokenStore.set(token);
    setUser(u ?? (await api.me()));
  };

  const login = async (email: string, password: string) => {
    const r = await api.login(email, password);
    await finish(r.token, r.user);
  };

  const register = async (name: string, email: string, password: string) => {
    const r = await api.register(name, email, password);
    if (r.token) await finish(r.token, r.user);
    else await login(email, password);
  };

  return (
    <AuthCtx.Provider value={{ user, loading, login, register, logout, setUser }}>{children}</AuthCtx.Provider>
  );
}
