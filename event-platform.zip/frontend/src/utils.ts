import type { EventItem } from './types';

const pad = (n: number) => String(n).padStart(2, '0');

/** YYYY-MM-DD key for an event date string. */
export function dateKey(d?: string): string {
  if (!d) return '';
  if (/^\d{4}-\d{2}-\d{2}/.test(d)) return d.slice(0, 10);
  const x = new Date(d);
  return isNaN(+x) ? '' : `${x.getFullYear()}-${pad(x.getMonth() + 1)}-${pad(x.getDate())}`;
}

export function fmtDate(d?: string): string {
  const k = dateKey(d);
  if (!k) return 'Date TBA';
  const [y, m, day] = k.split('-').map(Number);
  return new Date(y, m - 1, day).toLocaleDateString(undefined, {
    weekday: 'short', month: 'short', day: 'numeric', year: 'numeric',
  });
}

const timeOpts: Intl.DateTimeFormatOptions = { hour: 'numeric', minute: '2-digit' };

export function fmtTime(e: EventItem): string {
  if (e.time) {
    const m = /^(\d{1,2}):(\d{2})/.exec(e.time);
    if (m) {
      const d = new Date();
      d.setHours(+m[1], +m[2]);
      return d.toLocaleTimeString(undefined, timeOpts);
    }
    return e.time;
  }
  if (e.date?.includes('T')) {
    const d = new Date(e.date);
    if (!isNaN(+d)) return d.toLocaleTimeString(undefined, timeOpts);
  }
  return 'Time TBA';
}
