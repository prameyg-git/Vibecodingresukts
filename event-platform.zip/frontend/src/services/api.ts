import type { ChatReply, EventItem, InviteInfo, ReminderSettings, User } from '../types';

export const BASE_URL: string = import.meta.env.VITE_API_URL || 'http://localhost:5000';

/* ---------- token + errors ---------- */
const KEY = 'eventapp_token';
export const tokenStore = {
  get: () => localStorage.getItem(KEY),
  set: (t: string) => localStorage.setItem(KEY, t),
  clear: () => localStorage.removeItem(KEY),
};

export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

let unauthorizedHandler: (() => void) | null = null;
export const onUnauthorized = (fn: () => void) => { unauthorizedHandler = fn; };

/* ---------- core request ---------- */
type Opts = { method?: string; body?: unknown; params?: Record<string, string | undefined> };

async function request(path: string, { method = 'GET', body, params }: Opts = {}): Promise<any> {
  const url = new URL(path, BASE_URL);
  Object.entries(params ?? {}).forEach(([k, v]) => { if (v) url.searchParams.set(k, v); });
  const token = tokenStore.get();

  let res: Response;
  try {
    res = await fetch(url, {
      method,
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new ApiError(`Cannot reach the server at ${BASE_URL}. Is the backend running?`, 0);
  }

  const data = await res.json().catch(() => null);
  if (!res.ok) {
    if (res.status === 401 && token) unauthorizedHandler?.();
    throw new ApiError(data?.message || data?.error || `Request failed (${res.status})`, res.status);
  }
  return data;
}

/* ---------- response normalizers (adjust here if backend shapes differ) ---------- */
const pick = (o: any, ...keys: string[]) => {
  for (const k of keys) if (o?.[k] !== undefined && o?.[k] !== null && o?.[k] !== '') return o[k];
  return undefined;
};
const s = (v: unknown): string | undefined =>
  typeof v === 'string' || typeof v === 'number' ? String(v) : undefined;

function asList(d: any, ...keys: string[]): any[] {
  if (Array.isArray(d)) return d;
  for (const k of [...keys, 'data', 'results', 'items']) if (Array.isArray(d?.[k])) return d[k];
  return [];
}

export function normalizeEvent(raw: any): EventItem {
  const e = raw?.event && typeof raw.event === 'object' ? raw.event : raw ?? {};
  const start = e.dates?.start;
  const v = e.venue ?? e._embedded?.venues?.[0];
  const venue = typeof v === 'string' ? v : s(v?.name);
  const city = typeof v === 'object' ? s(v?.city?.name ?? v?.city) : undefined;
  const img = e.images?.[0];
  return {
    id: String(e.id ?? e._id ?? e.eventId ?? ''),
    title: s(pick(e, 'title', 'name')) ?? '',
    image: s(pick(e, 'image', 'imageUrl', 'thumbnail')) ?? s(typeof img === 'string' ? img : img?.url),
    venue: venue ?? s(pick(e, 'venueName')),
    date: s(pick(e, 'date', 'startDate', 'startDateTime', 'dateTime', 'localDate')) ?? s(start?.localDate ?? start?.dateTime),
    time: s(pick(e, 'time', 'startTime', 'localTime')) ?? s(start?.localTime),
    location: s(pick(e, 'location', 'city')) ?? city,
    url: s(pick(e, 'url', 'link')),
  };
}

function normalizeUser(d: any): User {
  const u = d?.user ?? d ?? {};
  return {
    id: String(u._id ?? u.id ?? ''),
    name: u.name ?? '',
    email: u.email ?? '',
    location: u.location ?? '',
    reminderSettings: u.reminderSettings ?? u.reminders ?? u.reminderPreferences,
  };
}

function rsvpEventId(r: any): string {
  const ev = r?.eventId;
  const id = typeof ev === 'object' && ev ? ev._id ?? ev.id : ev;
  return String(id ?? r?.event?.id ?? r?.event?._id ?? r?.id ?? r?._id ?? '');
}

/** Friends-attending count from a REST response or socket payload (undefined if absent). */
export function toCount(d: any): number | undefined {
  if (typeof d === 'number') return d;
  const c = pick(d, 'count', 'friendsAttending', 'friendsAttendingCount', 'total');
  if (typeof c === 'number') return c;
  if (Array.isArray(d?.friends)) return d.friends.length;
  if (Array.isArray(d)) return d.length;
  return undefined;
}

/* ---------- API surface ---------- */
export const api = {
  // auth
  async register(name: string, email: string, password: string) {
    const d = await request('/api/auth/register', { method: 'POST', body: { name, email, password } });
    return { token: d?.token as string | undefined, user: d?.user ? normalizeUser(d) : undefined };
  },
  async login(email: string, password: string) {
    const d = await request('/api/auth/login', { method: 'POST', body: { email, password } });
    return { token: d?.token as string | undefined, user: d?.user ? normalizeUser(d) : undefined };
  },
  async me(): Promise<User> {
    return normalizeUser(await request('/api/auth/me'));
  },

  // profile
  async getProfile(): Promise<User> {
    return normalizeUser(await request('/api/users/me'));
  },
  async updateProfile(patch: { name?: string; location?: string; reminderSettings?: ReminderSettings }): Promise<User> {
    // backend field is `reminderPreferences`
    const { reminderSettings, ...rest } = patch;
    const body = reminderSettings ? { ...rest, reminderPreferences: reminderSettings } : rest;
    return normalizeUser(await request('/api/users/me', { method: 'PATCH', body }));
  },

  // events
  async getEvents(
    params: { city?: string; keyword?: string; date?: string; startDate?: string; endDate?: string; size?: string } = {},
  ): Promise<EventItem[]> {
    const d = await request('/api/events', { params });
    return asList(d, 'events').map(normalizeEvent);
  },
  async getFriendsAttending(eventId: string): Promise<number> {
    return toCount(await request(`/api/events/${eventId}/friends`)) ?? 0;
  },

  // rsvps
  async getRsvps(): Promise<{ ids: string[]; events: EventItem[] }> {
    const list = asList(await request('/api/rsvps'), 'rsvps', 'events');
    const ids = list.map(rsvpEventId);
    let events = list.map((r) => {
      const nested = r?.event ?? (typeof r?.eventId === 'object' ? r.eventId : null);
      return normalizeEvent(nested ?? r);
    });
    events = events.map((e, i) => ({ ...e, id: e.id || ids[i] }));
    // Backend returned bare RSVP records (no event details): fill from the events feed.
    if (events.some((e) => !e.title)) {
      const all = await api.getEvents().catch(() => [] as EventItem[]);
      const byId = new Map(all.map((e) => [e.id, e]));
      events = events.map((e) => (e.title ? e : byId.get(e.id) ?? { ...e, title: 'Event' }));
    }
    return { ids, events };
  },
  async rsvp(eventId: string) {
    await request('/api/rsvps', { method: 'POST', body: { eventId } });
  },
  async cancelRsvp(eventId: string) {
    await request(`/api/rsvps/${eventId}`, { method: 'DELETE' });
  },

  // invites
  async createInvite(eventId: string): Promise<string> {
    const d = await request(`/api/events/${eventId}/invite`, { method: 'POST' });
    const link = s(pick(d, 'shareLink', 'link', 'url', 'inviteLink', 'inviteUrl', 'shareUrl'));
    if (link) return link;
    const token = s(pick(d, 'token', 'inviteToken'));
    if (token) return `${window.location.origin}/invite/${token}`; // token came from backend
    throw new ApiError('Backend did not return a share link', 500);
  },
  async getInvite(token: string): Promise<InviteInfo> {
    const d = await request(`/api/invites/${token}`);
    const inv = d?.inviter ?? d?.invitedBy ?? d?.sender;
    return {
      event: normalizeEvent(d?.event ?? d),
      inviter: typeof inv === 'string' ? inv : s(inv?.name),
    };
  },
  async acceptInvite(token: string) {
    await request(`/api/invites/${token}/rsvp`, { method: 'POST' });
  },

  // chat
  async chat(message: string): Promise<ChatReply> {
    const d = await request('/api/chat', { method: 'POST', body: { message } });
    const text = typeof d === 'string' ? d : s(pick(d, 'reply', 'message', 'response', 'text', 'answer')) ?? '';
    const raw = d?.events ?? d?.data?.events ?? d?.results ?? d?.rsvps ?? [];
    return { text, events: (Array.isArray(raw) ? raw : []).map(normalizeEvent) };
  },
};
