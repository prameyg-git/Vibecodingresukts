export interface ReminderSettings {
  enabled: boolean;
  hoursBefore: number;
}

export interface User {
  id: string;
  name: string;
  email: string;
  location?: string;
  reminderSettings?: ReminderSettings;
}

export interface EventItem {
  id: string;
  title: string;
  image?: string;
  venue?: string;
  date?: string;
  time?: string;
  location?: string;
  url?: string;
}

export interface ChatReply {
  text: string;
  events: EventItem[];
}

export interface ChatMessage extends ChatReply {
  role: 'user' | 'bot';
}

export interface InviteInfo {
  event: EventItem;
  inviter?: string;
}
