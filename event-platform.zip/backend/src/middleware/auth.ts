import { NextFunction, Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import { config } from '../config';
import { HttpError } from '../utils/errors';

declare global {
  namespace Express {
    interface Request {
      userId?: string;
    }
  }
}

function readToken(req: Request): string | null {
  const h = req.headers.authorization;
  return h && h.startsWith('Bearer ') ? h.slice(7) : null;
}

export function requireAuth(req: Request, _res: Response, next: NextFunction) {
  const token = readToken(req);
  if (!token) throw new HttpError(401, 'Authentication required');
  try {
    const payload = jwt.verify(token, config.jwtSecret) as jwt.JwtPayload;
    req.userId = payload.sub;
  } catch {
    throw new HttpError(401, 'Invalid or expired token');
  }
  next();
}

// Sets req.userId when a valid token is present, otherwise continues anonymously
export function optionalAuth(req: Request, _res: Response, next: NextFunction) {
  const token = readToken(req);
  if (token) {
    try {
      req.userId = (jwt.verify(token, config.jwtSecret) as jwt.JwtPayload).sub;
    } catch {
      /* ignore invalid token */
    }
  }
  next();
}
