import { ErrorRequestHandler, RequestHandler } from 'express';
import { HttpError } from '../utils/errors';

export const notFound: RequestHandler = (_req, res) => {
  res.status(404).json({ error: 'Route not found' });
};

export const errorHandler: ErrorRequestHandler = (err, _req, res, _next) => {
  if (err instanceof HttpError) {
    res.status(err.status).json({ error: err.message });
    return;
  }
  if (err?.code === 11000) {
    res.status(409).json({ error: 'Already exists' });
    return;
  }
  if (err?.name === 'ValidationError' || err?.name === 'CastError') {
    res.status(400).json({ error: err.message });
    return;
  }
  console.error(err);
  res.status(500).json({ error: 'Internal server error' });
};
