import 'dotenv/config';

export const config = {
  port: Number(process.env.PORT) || 5000,
  mongoUri: process.env.MONGODB_URI || '',
  jwtSecret: process.env.JWT_SECRET || '',
  tmKey: process.env.TICKETMASTER_API_KEY || '',
  tmBaseUrl: process.env.TICKETMASTER_BASE_URL || 'https://app.ticketmaster.com/discovery/v2',
  clientUrl: process.env.CLIENT_URL || 'http://localhost:5173',
};
