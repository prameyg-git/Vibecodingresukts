import { Schema, model } from 'mongoose';

const inviteSchema = new Schema(
  {
    token: { type: String, required: true, unique: true },
    eventId: { type: String, required: true, index: true },
    creatorUserId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    clickCount: { type: Number, default: 0 },
  },
  { timestamps: true }
);

// one invite link per user per event
inviteSchema.index({ eventId: 1, creatorUserId: 1 }, { unique: true });

export const Invite = model('Invite', inviteSchema);
