import { Schema, model } from 'mongoose';

const rsvpSchema = new Schema(
  {
    userId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    eventId: { type: String, required: true },
    status: { type: String, enum: ['going', 'interested'], default: 'going' },
    inviteId: { type: Schema.Types.ObjectId, ref: 'Invite', default: null },
  },
  { timestamps: true }
);

// prevents duplicate RSVPs
rsvpSchema.index({ userId: 1, eventId: 1 }, { unique: true });
rsvpSchema.index({ eventId: 1, inviteId: 1 });

export const Rsvp = model('Rsvp', rsvpSchema);
