import { Router } from 'express';
import { getEventById, searchEvents } from '../services/ticketmaster';
import { asyncHandler, DATE_RE, HttpError, str } from '../utils/errors';

const router = Router();

router.get(
  '/',
  asyncHandler(async (req, res) => {
    const date = str(req.query.date);
    if (date && !DATE_RE.test(date)) throw new HttpError(400, 'date must be YYYY-MM-DD');

    const startDate = str(req.query.startDate);
    const endDate = str(req.query.endDate);
    if ((startDate && !DATE_RE.test(startDate)) || (endDate && !DATE_RE.test(endDate))) {
      throw new HttpError(400, 'startDate/endDate must be YYYY-MM-DD');
    }
    const size = Math.min(Math.max(Number(str(req.query.size)) || 0, 0), 200) || undefined;

    const events = await searchEvents({
      keyword: str(req.query.keyword),
      city: str(req.query.city),
      date,
      startDate,
      endDate,
      size,
      category: str(req.query.category),
    });
    res.json({ count: events.length, events });
  })
);

router.get(
  '/:id',
  asyncHandler(async (req, res) => {
    const event = await getEventById(req.params.id);
    if (!event) throw new HttpError(404, 'Event not found');
    res.json({ event });
  })
);

export default router;
