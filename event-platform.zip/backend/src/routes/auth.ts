import bcrypt from 'bcrypt';
import { Router } from 'express';
import jwt from 'jsonwebtoken';
import { config } from '../config';
import { requireAuth } from '../middleware/auth';
import { User } from '../models/User';
import { asyncHandler, HttpError, str } from '../utils/errors';

const router = Router();
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const signToken = (userId: string) =>
  jwt.sign({}, config.jwtSecret, { subject: userId, expiresIn: '7d' });

router.post(
  '/register',
  asyncHandler(async (req, res) => {
    const name = str(req.body.name);
    const email = str(req.body.email)?.toLowerCase();
    const password = typeof req.body.password === 'string' ? req.body.password : '';

    if (!name) throw new HttpError(400, 'Name is required');
    if (!email || !EMAIL_RE.test(email)) throw new HttpError(400, 'Valid email is required');
    if (password.length < 6) throw new HttpError(400, 'Password must be at least 6 characters');
    if (await User.findOne({ email })) throw new HttpError(409, 'Email already registered');

    const user = await User.create({
      name,
      email,
      passwordHash: await bcrypt.hash(password, 10),
      location: str(req.body.location) || '',
    });
    res.status(201).json({ token: signToken(user.id), user });
  })
);

router.post(
  '/login',
  asyncHandler(async (req, res) => {
    const email = str(req.body.email)?.toLowerCase();
    const password = typeof req.body.password === 'string' ? req.body.password : '';
    if (!email || !password) throw new HttpError(400, 'Email and password are required');

    const user = await User.findOne({ email });
    if (!user || !(await bcrypt.compare(password, user.passwordHash))) {
      throw new HttpError(401, 'Invalid email or password');
    }
    res.json({ token: signToken(user.id), user });
  })
);

router.get(
  '/me',
  requireAuth,
  asyncHandler(async (req, res) => {
    const user = await User.findById(req.userId);
    if (!user) throw new HttpError(401, 'User no longer exists');
    res.json({ user });
  })
);

export default router;
