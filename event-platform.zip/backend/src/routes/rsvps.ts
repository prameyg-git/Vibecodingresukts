import { Router } from 'express';
import { requireAuth } from '../middleware/auth';
import { Rsvp } from '../models/Rsvp';
import { getUserRsvpsWithEvents } from '../services/rsvpService';
import { emitFriendsAttending } from '../socket';
import { getEventById } from '../services/ticketmaster';
import { asyncHandler, HttpError, str } from '../utils/errors';

const router = Router();
router.use(requireAuth);

router.get(
  '/',
  asyncHandler(async (req, res) => {
    res.json({ rsvps: await getUserRsvpsWithEvents(req.userId!) });
  })
);

router.post(
  '/',
  asyncHandler(async (req, res) => {
    const eventId = str(req.body.eventId);
    const status = str(req.body.status) || 'going';
    if (!eventId) throw new HttpError(400, 'eventId is required');
    if (!['going', 'interested'].includes(status)) throw new HttpError(400, 'status must be going or interested');
    if (!(await getEventById(eventId))) throw new HttpError(404, 'Event not found');
    if (await Rsvp.findOne({ userId: req.userId, eventId })) throw new HttpError(409, 'You have already RSVPed to this event');

    const rsvp = await Rsvp.create({ userId: req.userId, eventId, status });
    res.status(201).json({ rsvp });
  })
);

router.delete(
  '/:eventId',
  asyncHandler(async (req, res) => {
    const rsvp = await Rsvp.findOneAndDelete({ userId: req.userId, eventId: req.params.eventId });
    if (!rsvp) throw new HttpError(404, 'RSVP not found');
    // if this was an invite-based RSVP, the friends count changed
    if (rsvp.inviteId) await emitFriendsAttending(rsvp.eventId);
    res.json({ message: 'RSVP removed' });
  })
);

export default router;
