import { Router } from 'express';
import { requireAuth } from '../middleware/auth';
import { User } from '../models/User';
import { asyncHandler, HttpError, str } from '../utils/errors';

const router = Router();
router.use(requireAuth);

router.get(
  '/me',
  asyncHandler(async (req, res) => {
    const user = await User.findById(req.userId);
    if (!user) throw new HttpError(404, 'User not found');
    res.json({ user });
  })
);

router.patch(
  '/me',
  asyncHandler(async (req, res) => {
    const update: Record<string, unknown> = {};
    const { name, location, reminderPreferences: rp } = req.body;

    if (name !== undefined) {
      if (!str(name)) throw new HttpError(400, 'Name cannot be empty');
      update.name = str(name);
    }
    if (location !== undefined) {
      if (typeof location !== 'string') throw new HttpError(400, 'location must be a string');
      update.location = location.trim();
    }
    if (rp !== undefined) {
      if (typeof rp !== 'object' || rp === null) throw new HttpError(400, 'reminderPreferences must be an object');
      if (rp.enabled !== undefined) {
        if (typeof rp.enabled !== 'boolean') throw new HttpError(400, 'enabled must be boolean');
        update['reminderPreferences.enabled'] = rp.enabled;
      }
      if (rp.email !== undefined) {
        if (typeof rp.email !== 'boolean') throw new HttpError(400, 'email must be boolean');
        update['reminderPreferences.email'] = rp.email;
      }
      if (rp.hoursBefore !== undefined) {
        if (typeof rp.hoursBefore !== 'number' || rp.hoursBefore < 1 || rp.hoursBefore > 168) {
          throw new HttpError(400, 'hoursBefore must be a number between 1 and 168');
        }
        update['reminderPreferences.hoursBefore'] = rp.hoursBefore;
      }
    }

    const user = await User.findByIdAndUpdate(req.userId, { $set: update }, { new: true, runValidators: true });
    if (!user) throw new HttpError(404, 'User not found');
    res.json({ user });
  })
);

export default router;
