import { Router } from 'express';
import { optionalAuth } from '../middleware/auth';
import { getUserRsvpsWithEvents } from '../services/rsvpService';
import { EventQuery, searchEvents } from '../services/ticketmaster';
import { asyncHandler, HttpError, str } from '../utils/errors';

const router = Router();

const dayStr = (offset: number) => {
  const d = new Date();
  d.setDate(d.getDate() + offset);
  return d.toISOString().slice(0, 10);
};

const CATEGORIES: [RegExp, string][] = [
  [/music|concert|band/i, 'Music'],
  [/sport|game|match/i, 'Sports'],
  [/art|theat|comedy|play/i, 'Arts & Theatre'],
  [/film|movie|cinema/i, 'Film'],
  [/family|misc/i, 'Miscellaneous'],
];

router.post(
  '/',
  optionalAuth,
  asyncHandler(async (req, res) => {
    const message = str(req.body.message);
    if (!message) throw new HttpError(400, 'message is required');
    const text = message.toLowerCase();

    // 1. My RSVPs
    if (/\brsvps?\b|\battending\b/.test(text) && /\bmy\b|\bi\b/.test(text)) {
      if (!req.userId) throw new HttpError(401, 'Log in to see your RSVPs');
      const rsvps = await getUserRsvpsWithEvents(req.userId);
      const events = rsvps.map((r) => r.event).filter(Boolean);
      res.json({
        reply: events.length ? `You have ${events.length} RSVP(s).` : "You haven't RSVPed to any events yet.",
        events,
      });
      return;
    }

    // 2. Event search
    const query: EventQuery = { size: 10 };
    const parts: string[] = [];

    if (/weekend/.test(text)) {
      const day = new Date().getDay(); // 0 = Sunday
      const start = day === 0 ? 0 : 6 - day;
      const end = day === 0 ? 0 : start + 1;
      query.startDate = dayStr(start);
      query.endDate = dayStr(end);
      parts.push('this weekend');
    } else if (/tomorrow/.test(text)) {
      query.date = dayStr(1);
      parts.push('tomorrow');
    } else if (/today|tonight/.test(text)) {
      query.date = dayStr(0);
      parts.push('today');
    }

    const cat = CATEGORIES.find(([re]) => re.test(text));
    if (cat) {
      query.category = cat[1];
      parts.push(`in ${cat[1]}`);
    }

    const cityMatch = message.match(/\bin\s+([a-z][a-z .'-]*?)(?=\s+(?:this|on|tomorrow|today|next|for|during)\b|[?.!,\s]*$)/i);
    if (cityMatch) {
      query.city = cityMatch[1].trim();
      parts.push(`in ${query.city}`);
    }

    if (!parts.length) {
      res.json({
        reply: 'Try: "events this weekend", "events tomorrow", "music events", "events in London" or "my RSVPs".',
        events: [],
      });
      return;
    }

    const events = await searchEvents(query);
    res.json({
      reply: events.length ? `Found ${events.length} event(s) ${parts.join(' ')}.` : `No events found ${parts.join(' ')}.`,
      events,
    });
  })
);

export default router;
