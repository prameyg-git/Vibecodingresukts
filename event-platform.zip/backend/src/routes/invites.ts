import crypto from 'crypto';
import { Router } from 'express';
import { config } from '../config';
import { requireAuth } from '../middleware/auth';
import { Invite } from '../models/Invite';
import { Rsvp } from '../models/Rsvp';
import { countFriendsAttending, countInviteClicks } from '../services/friends';
import { getEventById } from '../services/ticketmaster';
import { emitFriendsAttending } from '../socket';
import { asyncHandler, HttpError } from '../utils/errors';

const router = Router();

// Create (or reuse) an invite link - only for users who RSVPed
router.post(
  '/events/:eventId/invite',
  requireAuth,
  asyncHandler(async (req, res) => {
    const { eventId } = req.params;
    if (!(await Rsvp.findOne({ userId: req.userId, eventId }))) {
      throw new HttpError(403, 'You must RSVP to this event before inviting friends');
    }

    let invite = await Invite.findOne({ eventId, creatorUserId: req.userId });
    const created = !invite;
    if (!invite) {
      invite = await Invite.create({
        token: crypto.randomBytes(9).toString('base64url'),
        eventId,
        creatorUserId: req.userId,
      });
    }
    res.status(created ? 201 : 200).json({
      token: invite.token,
      eventId,
      clickCount: invite.clickCount,
      url: `${config.clientUrl}/invite/${invite.token}`,
    });
  })
);

// Open an invite: counts a click and returns the event
router.get(
  '/invites/:token',
  asyncHandler(async (req, res) => {
    const invite = await Invite.findOneAndUpdate(
      { token: req.params.token },
      { $inc: { clickCount: 1 } },
      { new: true }
    ).populate('creatorUserId', 'name');
    if (!invite) throw new HttpError(404, 'Invite not found');

    const event = await getEventById(invite.eventId);
    if (!event) throw new HttpError(404, 'Event not found');

    res.json({
      token: invite.token,
      event,
      invitedBy: (invite.creatorUserId as any)?.name || null,
      inviteClicks: invite.clickCount,
      friendsAttending: await countFriendsAttending(invite.eventId),
    });
  })
);

// RSVP through an invite: counts as a friend attending
router.post(
  '/invites/:token/rsvp',
  requireAuth,
  asyncHandler(async (req, res) => {
    const invite = await Invite.findOne({ token: req.params.token });
    if (!invite) throw new HttpError(404, 'Invite not found');
    if (String(invite.creatorUserId) === req.userId) {
      throw new HttpError(400, 'You cannot RSVP through your own invite');
    }
    if (await Rsvp.findOne({ userId: req.userId, eventId: invite.eventId })) {
      throw new HttpError(409, 'You have already RSVPed to this event');
    }

    const rsvp = await Rsvp.create({
      userId: req.userId,
      eventId: invite.eventId,
      status: 'going',
      inviteId: invite._id,
    });
    const friendsAttending = await emitFriendsAttending(invite.eventId);
    res.status(201).json({ rsvp, eventId: invite.eventId, friendsAttending });
  })
);

// Friends attending (from invite-based RSVPs) vs invite clicks
router.get(
  '/events/:eventId/friends',
  requireAuth,
  asyncHandler(async (req, res) => {
    const { eventId } = req.params;
    const rsvps = await Rsvp.find({ eventId, inviteId: { $ne: null }, status: 'going' }).populate('userId', 'name');
    res.json({
      eventId,
      inviteClicks: await countInviteClicks(eventId),
      friendsAttending: rsvps.length,
      friends: rsvps.map((r) => ({ id: (r.userId as any)._id, name: (r.userId as any).name })),
    });
  })
);

export default router;
