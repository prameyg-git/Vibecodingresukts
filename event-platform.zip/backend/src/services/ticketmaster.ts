import { config } from '../config';
import { HttpError } from '../utils/errors';

export interface EventDTO {
  id: string;
  title: string;
  description: string;
  date: string;
  startTime: string;
  venue: string;
  address: string;
  city: string;
  image: string;
  category: string;
  url: string;
}

export interface EventQuery {
  keyword?: string;
  city?: string;
  date?: string; // exact day YYYY-MM-DD
  startDate?: string; // range start YYYY-MM-DD
  endDate?: string; // range end YYYY-MM-DD
  category?: string;
  size?: number;
}

// Remembers events we have already seen so RSVP lists don't re-hit the API
const cache = new Map<string, EventDTO>();

const isoDay = (offset: number) => {
  const d = new Date();
  d.setDate(d.getDate() + offset);
  return d.toISOString().slice(0, 10);
};

// ---------- Mock data (used when no Ticketmaster key is set) ----------
const mockEvents = (): EventDTO[] => {
  const mk = (n: number, offset: number, title: string, category: string, city: string, venue: string): EventDTO => ({
    id: `mock-${n}`,
    title,
    description: `${title} - a sample event for local development.`,
    date: isoDay(offset),
    startTime: '19:00:00',
    venue,
    address: `${n} Main Street`,
    city,
    image: '',
    category,
    url: 'https://example.com/events/' + n,
  });
  return [
    mk(1, 0, 'Indie Rock Night', 'Music', 'New York', 'Brooklyn Hall'),
    mk(2, 1, 'City Marathon Expo', 'Sports', 'Chicago', 'Lakeside Arena'),
    mk(3, 2, 'Jazz Under the Stars', 'Music', 'Los Angeles', 'Griffith Stage'),
    mk(4, 3, 'Shakespeare in the Park', 'Arts & Theatre', 'New York', 'Central Amphitheater'),
    mk(5, 4, 'Open Air Cinema', 'Film', 'London', 'Riverside Lawn'),
    mk(6, 5, 'Basketball Finals', 'Sports', 'Los Angeles', 'Downtown Arena'),
    mk(7, 6, 'Stand-up Comedy Showcase', 'Arts & Theatre', 'Chicago', 'Laugh Factory'),
    mk(8, 7, 'Electronic Music Festival', 'Music', 'Mumbai', 'Bandra Grounds'),
    mk(9, 8, 'Family Fun Fair', 'Miscellaneous', 'London', 'Hyde Fairground'),
    mk(10, 9, 'Classical Orchestra Evening', 'Music', 'Mumbai', 'NCPA Hall'),
  ];
};

function filterMock(q: EventQuery): EventDTO[] {
  const start = q.date || q.startDate;
  const end = q.date || q.endDate;
  const has = (text: string, needle?: string) => !needle || text.toLowerCase().includes(needle.toLowerCase());
  return mockEvents().filter(
    (e) =>
      has(`${e.title} ${e.description} ${e.venue}`, q.keyword) &&
      has(e.city, q.city) &&
      has(e.category, q.category) &&
      (!start || e.date >= start) &&
      (!end || e.date <= end)
  );
}

// ---------- Ticketmaster ----------
async function tmFetch(path: string, params: Record<string, string | undefined>): Promise<any | null> {
  const url = new URL(`${config.tmBaseUrl}${path}`);
  url.searchParams.set('apikey', config.tmKey);
  for (const [k, v] of Object.entries(params)) if (v) url.searchParams.set(k, v);

  let res: Response;
  try {
    res = await fetch(url);
  } catch {
    throw new HttpError(502, 'Could not reach Ticketmaster');
  }
  if (res.status === 404) return null;
  if (!res.ok) throw new HttpError(502, `Ticketmaster request failed (${res.status})`);
  return res.json();
}

function normalize(e: any): EventDTO {
  const venue = e._embedded?.venues?.[0];
  const image = [...(e.images || [])].sort((a: any, b: any) => (b.width || 0) - (a.width || 0))[0];
  return {
    id: e.id,
    title: e.name || '',
    description: e.info || e.pleaseNote || '',
    date: e.dates?.start?.localDate || '',
    startTime: e.dates?.start?.localTime || '',
    venue: venue?.name || '',
    address: venue?.address?.line1 || '',
    city: venue?.city?.name || '',
    image: image?.url || '',
    category: e.classifications?.[0]?.segment?.name || '',
    url: e.url || '',
  };
}

export async function searchEvents(q: EventQuery): Promise<EventDTO[]> {
  let events: EventDTO[];

  if (!config.tmKey) {
    events = filterMock(q);
  } else {
    const start = q.date || q.startDate;
    const end = q.date || q.endDate;
    const data = await tmFetch('/events.json', {
      keyword: q.keyword,
      city: q.city,
      classificationName: q.category,
      startDateTime: start ? `${start}T00:00:00Z` : undefined,
      endDateTime: end ? `${end}T23:59:59Z` : undefined,
      size: String(q.size || 20),
      sort: 'date,asc',
    });
    events = (data?._embedded?.events || []).map(normalize);
  }

  events.forEach((e) => cache.set(e.id, e));
  return events;
}

export async function getEventById(id: string): Promise<EventDTO | null> {
  const cached = cache.get(id);
  if (cached) return cached;

  let event: EventDTO | null = null;
  if (!config.tmKey) {
    event = mockEvents().find((e) => e.id === id) || null;
  } else {
    const data = await tmFetch(`/events/${encodeURIComponent(id)}.json`, {});
    event = data ? normalize(data) : null;
  }
  if (event) cache.set(event.id, event);
  return event;
}
