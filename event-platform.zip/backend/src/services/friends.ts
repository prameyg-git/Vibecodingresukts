import { Invite } from '../models/Invite';
import { Rsvp } from '../models/Rsvp';

// Friends attending = RSVPs that were made THROUGH an invite (not invite clicks)
export const countFriendsAttending = (eventId: string) =>
  Rsvp.countDocuments({ eventId, inviteId: { $ne: null }, status: 'going' });

// Total times invite links for this event were opened
export async function countInviteClicks(eventId: string): Promise<number> {
  const invites = await Invite.find({ eventId }).select('clickCount');
  return invites.reduce((sum, i) => sum + (i.clickCount || 0), 0);
}
