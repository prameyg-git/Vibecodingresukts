import { Rsvp } from '../models/Rsvp';
import { getEventById } from './ticketmaster';

export async function getUserRsvpsWithEvents(userId: string) {
  const rsvps = await Rsvp.find({ userId }).sort({ createdAt: -1 });
  return Promise.all(
    rsvps.map(async (r) => ({
      id: r.id,
      eventId: r.eventId,
      status: r.status,
      inviteId: r.inviteId,
      createdAt: (r as any).createdAt,
      updatedAt: (r as any).updatedAt,
      event: await getEventById(r.eventId).catch(() => null),
    }))
  );
}
