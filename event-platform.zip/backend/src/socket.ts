import http from 'http';
import { Server } from 'socket.io';
import { config } from './config';
import { countFriendsAttending } from './services/friends';

let io: Server | null = null;

export function initSocket(server: http.Server) {
  io = new Server(server, { cors: { origin: config.clientUrl } });
  io.on('connection', (socket) => {
    console.log('Socket connected:', socket.id);
  });
}

// Recounts friends attending from MongoDB and broadcasts it
export async function emitFriendsAttending(eventId: string): Promise<number> {
  const friendsAttending = await countFriendsAttending(eventId);
  io?.emit('friends-attending-updated', { eventId, friendsAttending });
  return friendsAttending;
}
