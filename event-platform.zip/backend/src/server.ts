import http from 'http';
import mongoose from 'mongoose';
import app from './app';
import { config } from './config';
import { initSocket } from './socket';

async function start() {
  if (!config.mongoUri || !config.jwtSecret) {
    console.error('MONGODB_URI and JWT_SECRET must be set in .env');
    process.exit(1);
  }
  await mongoose.connect(config.mongoUri);
  console.log('MongoDB connected');
  if (!config.tmKey) console.log('No TICKETMASTER_API_KEY set - using mock events');

  const server = http.createServer(app);
  initSocket(server);
  server.listen(config.port, () => console.log(`Server running on port ${config.port}`));
}

start().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
