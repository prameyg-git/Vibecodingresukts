import cors from 'cors';
import express from 'express';
import { config } from './config';
import { errorHandler, notFound } from './middleware/error';
import authRoutes from './routes/auth';
import chatRoutes from './routes/chat';
import eventRoutes from './routes/events';
import inviteRoutes from './routes/invites';
import rsvpRoutes from './routes/rsvps';
import userRoutes from './routes/users';

const app = express();

app.use(cors({ origin: config.clientUrl }));
app.use(express.json());

app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok' });
});
app.use('/api/auth', authRoutes);
app.use('/api/events', eventRoutes);
app.use('/api/rsvps', rsvpRoutes);
app.use('/api/users', userRoutes);
app.use('/api/chat', chatRoutes);
app.use('/api', inviteRoutes); // /events/:eventId/invite, /events/:eventId/friends, /invites/:token...

app.use(notFound);
app.use(errorHandler);

export default app;
